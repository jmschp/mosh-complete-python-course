print("Test file, for learning how to work with files and folders")
print("Test from lesson 04 Working with Files")