# 01 Python Standard Library

# In this section we are going to learn about Python standard library
# How to work with:
    # Files
    # SQLite
    # Date/Time
    # Random Values
    # Emails